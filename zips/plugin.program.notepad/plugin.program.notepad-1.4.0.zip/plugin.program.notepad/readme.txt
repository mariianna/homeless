Notepad
~~~~~~~

v1.4 (Saturday, 14 August 2010) :
 - Confluence skin; 
 - Italian translation (thanks to KymyA);

v1.3 (Saturday, 3 April 2010)
 - Display message if the file doesn't exist;
 - Show progress dialog (might be useful for larger files, although slower);
 - Add editor scrollbars;
 - Do not append new-line at the end of the file;

v1.2 (Friday, 26 February 2010):
 - MediaStream Redux skin;
 - Remember recent files;
 - Add description.xml (used by SVN Repo Installer);

v1.1 (Friday, 22 January 2010):
 - Rapier skin;