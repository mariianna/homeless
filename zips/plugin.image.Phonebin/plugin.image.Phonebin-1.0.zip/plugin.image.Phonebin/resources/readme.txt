Phonebin.com - XBMC Pictures/Plugin to display website content - WARNING: ADULT CONTENT!


SETUP:
 Install to Plugins\Pictures\Phonebin  (IMPORTANT! keep sub folder structure intact)


USAGE: 
 1) From XBMC Home Screen choose "Pictures"
 2) Select "Plugins"
 3) Select "Phonebin"
    Plugin will run and present you with is Root Categories.
 4) Select a category and a list of items will be shown
 5) Select an item to display item details

SETTINGS:
 From Pictures folder, highlight Addon and press Contextmenu button.
 Options:
    i) Pagesize - Number of photo fetched per page (Website shows in multiples of 20)


CREDITS:
 Written By BigBellyBilly

 Thanks to others who've contributed.

 Project Homepage: http://code.google.com/p/xbmc-addons/

 Forum: http://xbmc.org/forum/

 XBMC Homepage: http://xbmc.org/

Feedback, Suggestion and bug reports welcome!
enjoy!
